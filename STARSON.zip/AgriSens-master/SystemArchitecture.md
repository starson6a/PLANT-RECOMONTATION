| System Architecture |
|---------------------|
|<img src="https://github.com/user-attachments/assets/33f5cd9a-0b4e-48a2-a49b-49d9c70d8319"/> |
